"""
app.py — Frontend Flask para o Jogo da Velha × IA
T1 – Inteligência Artificial | PUCRS | Grupo T32

Para rodar:
    pip install -r requirements.txt
    python app.py
Acesse: http://localhost:5000
"""

import os
import random
import numpy as np
from flask import Flask, render_template, request, jsonify

# ── Tentativa de carregar modelos treinados ─────────────────────────────────
MODELS_DIR_32 = os.path.join(os.path.dirname(__file__), 'models')

model_32       = None
scaler_32      = None
le_32          = None
model_name_32  = 'Fallback (Regras)'
model_loaded_32 = False

try:
    import joblib
    model_32  = joblib.load(os.path.join(MODELS_DIR_32, 'melhor_modelo_32.pkl'))
    scaler_32 = joblib.load(os.path.join(MODELS_DIR_32, 'scaler_32.pkl'))
    le_32     = joblib.load(os.path.join(MODELS_DIR_32, 'le_32.pkl'))
    info_path = os.path.join(MODELS_DIR_32, 'model_info_32.txt')
    if os.path.exists(info_path):
        with open(info_path, 'r') as f:
            model_name_32 = f.read().strip()
    model_loaded_32 = True
    print(f'[OK] Modelo carregado: {model_name_32}')
except Exception as e:
    print(f'[INFO] Modelos nao encontrados ({e}). Usando modo fallback (logica de regras).')

# ── Lógica determinística do tabuleiro ─────────────────────────────────────
WIN_LINES_32 = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),
    (0, 3, 6), (1, 4, 7), (2, 5, 8),
    (0, 4, 8), (2, 4, 6)
]
ENCODE_MAP_32 = {'x': 1, 'o': -1, 'b': 0}


def check_winner_32(board):
    """Retorna 'x', 'o' ou None."""
    for a, b, c in WIN_LINES_32:
        if board[a] == board[b] == board[c] and board[a] != 'b':
            return board[a]
    return None


def classify_board_32(board):
    """Classifica o estado: 'x_venceu' | 'o_venceu' | 'empate' | 'tem_jogo'."""
    winner = check_winner_32(board)
    if winner == 'x':
        return 'x_venceu'
    if winner == 'o':
        return 'o_venceu'
    if 'b' not in board:
        return 'empate'
    return 'tem_jogo'


def ia_predict_32(board):
    """Prediz o estado usando o modelo ML ou, se ausente, a lógica de regras."""
    if not model_loaded_32:
        return classify_board_32(board)
    encoded = np.array([ENCODE_MAP_32[v] for v in board], dtype=float).reshape(1, -1)
    scaled  = scaler_32.transform(encoded)
    pred_int = model_32.predict(scaled)[0]
    return le_32.inverse_transform([int(pred_int)])[0]


# ── Estado da sessão (in-memory, reiniciado ao iniciar o servidor) ──────────
session_32 = {
    'total_predicoes_32': 0,
    'acertos_32':         0,
    'historico_32':       []
}

# ── App Flask ───────────────────────────────────────────────────────────────
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/status')
def api_status_32():
    return jsonify({
        'model_loaded_32': model_loaded_32,
        'model_name_32':   model_name_32
    })


@app.route('/api/new_game')
def api_new_game_32():
    session_32['total_predicoes_32'] = 0
    session_32['acertos_32']         = 0
    session_32['historico_32']       = []
    return jsonify({
        'board_32':         ['b'] * 9,
        'model_loaded_32':  model_loaded_32,
        'model_name_32':    model_name_32
    })


@app.route('/api/move', methods=['POST'])
def api_move_32():
    data_32    = request.get_json()
    board_32   = list(data_32['board_32'])
    position_32 = int(data_32['position_32'])

    # Validação
    if position_32 < 0 or position_32 > 8 or board_32[position_32] != 'b':
        return jsonify({'error': 'Posicao invalida'}), 400

    # ── Jogada do Humano (X) ────────────────────────────────────────────────
    board_32[position_32] = 'x'
    true_x_32 = classify_board_32(board_32)
    pred_x_32 = ia_predict_32(board_32)
    correct_x_32 = (true_x_32 == pred_x_32)

    session_32['total_predicoes_32'] += 1
    if correct_x_32:
        session_32['acertos_32'] += 1
    session_32['historico_32'].append({
        'jogador_32': 'Humano (X)',
        'true_32':    true_x_32,
        'pred_32':    pred_x_32,
        'correto_32': correct_x_32
    })

    # Comportamento especial após jogada humana
    game_over_32    = False
    ia_stopped_32   = False
    ia_false_end_32 = False
    cpu_position_32 = None
    true_o_32 = pred_o_32 = correct_o_32 = None

    if true_x_32 != 'tem_jogo':
        game_over_32 = True
        if pred_x_32 == 'tem_jogo':
            ia_stopped_32 = True    # IA não detectou fim → encerrar
    else:
        if pred_x_32 != 'tem_jogo':
            ia_false_end_32 = True  # IA detectou fim incorretamente → continuar

        # ── Jogada do CPU (O) — aleatório ──────────────────────────────────
        empty_32 = [i for i, v in enumerate(board_32) if v == 'b']
        if empty_32:
            cpu_position_32 = random.choice(empty_32)
            board_32[cpu_position_32] = 'o'

            true_o_32  = classify_board_32(board_32)
            pred_o_32  = ia_predict_32(board_32)
            correct_o_32 = (true_o_32 == pred_o_32)

            session_32['total_predicoes_32'] += 1
            if correct_o_32:
                session_32['acertos_32'] += 1
            session_32['historico_32'].append({
                'jogador_32': 'CPU (O)',
                'true_32':    true_o_32,
                'pred_32':    pred_o_32,
                'correto_32': correct_o_32
            })

            if true_o_32 != 'tem_jogo':
                game_over_32 = True
                if pred_o_32 == 'tem_jogo':
                    ia_stopped_32 = True
            elif pred_o_32 != 'tem_jogo':
                ia_false_end_32 = True

    total_32   = session_32['total_predicoes_32']
    acertos_32 = session_32['acertos_32']
    accuracy_32 = round(acertos_32 / total_32, 4) if total_32 > 0 else None

    return jsonify({
        'board_32':          board_32,
        'cpu_position_32':   cpu_position_32,
        'pred_x_32':         pred_x_32,
        'true_x_32':         true_x_32,
        'correct_x_32':      correct_x_32,
        'pred_o_32':         pred_o_32,
        'true_o_32':         true_o_32,
        'correct_o_32':      correct_o_32,
        'game_over_32':      game_over_32,
        'ia_stopped_32':     ia_stopped_32,
        'ia_false_end_32':   ia_false_end_32,
        'total_preds_32':    total_32,
        'acertos_32':        acertos_32,
        'accuracy_32':       accuracy_32,
        'model_mode_32':     'ML' if model_loaded_32 else 'Fallback',
        'model_name_32':     model_name_32
    })


if __name__ == '__main__':
    print('=== Jogo da Velha × IA — T1 PUCRS Grupo 32 ===')
    print(f'Modo: {"ML (" + model_name_32 + ")" if model_loaded_32 else "Fallback (regras)"}')
    print('Acesse: http://localhost:5000')
    app.run(debug=True, port=5000)
